import java.util.*;
import java.util.function.*;

/**
 * Functional Interfaces Activity — SOLUTION
 * Configurable Entity System
 * March 6, 2026 · Java Concepts · 15 Points
 */
public class FunctionalActivity {

    // ══════════════════════════════════════════════════════════════════
    // GAME ENTITY CLASSES (provided)
    // ══════════════════════════════════════════════════════════════════

    static class Player {
        String name;
        int health;
        double speed;
        int score;

        Player(String name, int health, double speed) {
            this.name = name;
            this.health = health;
            this.speed = speed;
            this.score = 0;
        }

        void jump()     { System.out.println(name + " jumps!"); }
        void dash()     { System.out.println(name + " dashes! Speed: " + (speed * 2)); }
        void attack()   { System.out.println(name + " attacks!"); }
        void interact() { System.out.println(name + " interacts with nearby object."); }
        void addScore(int pts) { score += pts; System.out.println(name + " +" + pts + " pts! (Total: " + score + ")"); }
        void takeDamage(int dmg) { health -= dmg; System.out.println(name + " takes " + dmg + " damage! HP: " + health); }

        @Override
        public String toString() {
            return String.format("%-10s | HP: %3d | Speed: %.1f | Score: %d", name, health, speed, score);
        }
    }

    static class Enemy {
        String type;
        int health;
        int damage;
        boolean isActive;

        Enemy(String type, int health, int damage) {
            this.type = type;
            this.health = health;
            this.damage = damage;
            this.isActive = true;
        }

        void deactivate() { isActive = false; System.out.println("  " + type + " defeated!"); }

        @Override
        public String toString() {
            return String.format("%-10s | HP: %3d | DMG: %2d | %s", type, health, damage, isActive ? "ACTIVE" : "DEAD");
        }
    }


    // ══════════════════════════════════════════════════════════════════
    //  PART 1: Custom Functional Interfaces (3 pts)
    // ══════════════════════════════════════════════════════════════════

    // TODO 1a: DamageCalculator
    @FunctionalInterface
    interface DamageCalculator {
        int calculate(int baseDamage, int armor, double critMultiplier);
    }

    // TODO 1b: PowerUp
    @FunctionalInterface
    interface PowerUp {
        double apply(int currentHealth, double currentSpeed);
    }


    // ══════════════════════════════════════════════════════════════════
    //  PART 2: Filtering & Transformation with Lambdas (4 pts)
    // ══════════════════════════════════════════════════════════════════

    // TODO 2a
    static List<Enemy> filterEnemies(List<Enemy> enemies, Predicate<Enemy> condition) {
        List<Enemy> result = new ArrayList<>();
        for (Enemy enemy : enemies) {
            if (condition.test(enemy)) {
                result.add(enemy);
            }
        }
        return result;
    }

    // TODO 2b
    static List<String> transformAll(List<String> items, Function<String, String> transformer) {
        List<String> result = new ArrayList<>();
        for (String item : items) {
            result.add(transformer.apply(item));
        }
        return result;
    }


    // ══════════════════════════════════════════════════════════════════
    //  PART 3: Configurable Behaviors (4 pts)
    // ══════════════════════════════════════════════════════════════════

    // TODO 3a
    static void applyToAll(List<Enemy> enemies, Consumer<Enemy> behavior) {
        for (Enemy enemy : enemies) {
            behavior.accept(enemy);
        }
    }


    // ══════════════════════════════════════════════════════════════════
    //  MAIN METHOD
    // ══════════════════════════════════════════════════════════════════

    public static void main(String[] args) {

        System.out.println("╔══════════════════════════════════════════════╗");
        System.out.println("║   Functional Interfaces Activity             ║");
        System.out.println("╚══════════════════════════════════════════════╝\n");

        // ── SETUP ───────────────────────────────────────────────────
        Player player = new Player("Hero", 100, 5.0);

        List<Enemy> enemies = new ArrayList<>(Arrays.asList(
            new Enemy("Slime",    30,  5),
            new Enemy("Skeleton", 60, 12),
            new Enemy("Dragon",  150, 35),
            new Enemy("Bat",      15,  3),
            new Enemy("Golem",   200, 20),
            new Enemy("Ghost",    40, 15)
        ));

        List<String> playerNames = Arrays.asList("alice", "bob", "charlie", "diana");


        // ════════════════════════════════════════════════════════════
        //  PART 1 TESTS
        // ════════════════════════════════════════════════════════════
        System.out.println("═══ PART 1: Custom Functional Interfaces ═══\n");

        // TODO 1c
        DamageCalculator standardCalc = (base, armor, crit) -> (int) ((base - armor) * crit);

        // TODO 1d
        DamageCalculator piercingCalc = (base, armor, crit) -> (int) (base * crit);

        // TODO 1e
        PowerUp speedBoost = (health, speed) -> health > 50 ? speed * 2 : speed;
        PowerUp steadyBoost = (health, speed) -> speed + 2.0;

        System.out.println("Standard damage (50 base, 20 armor, 1.5x crit): " + standardCalc.calculate(50, 20, 1.5));
        System.out.println("Piercing damage (50 base, 20 armor, 1.5x crit): " + piercingCalc.calculate(50, 20, 1.5));
        System.out.println("Speed boost (HP=100, speed=5.0): " + speedBoost.apply(100, 5.0));
        System.out.println("Speed boost (HP=30, speed=5.0): " + speedBoost.apply(30, 5.0));
        System.out.println("Steady boost (HP=anything, speed=5.0): " + steadyBoost.apply(50, 5.0));

        System.out.println();


        // ════════════════════════════════════════════════════════════
        //  PART 2 TESTS
        // ════════════════════════════════════════════════════════════
        System.out.println("═══ PART 2: Filtering & Transformation ═══\n");

        // TODO 2c
        System.out.println("Strong enemies (HP > 50):");
        List<Enemy> strongEnemies = filterEnemies(enemies, e -> e.health > 50);
        strongEnemies.forEach(System.out::println);

        System.out.println();

        // TODO 2d
        System.out.println("Weak enemies (DMG < 15):");
        List<Enemy> weakEnemies = filterEnemies(enemies, e -> e.damage < 15);
        weakEnemies.forEach(System.out::println);

        System.out.println();

        // TODO 2e
        System.out.println("Scoreboard names:");
        List<String> upperNames = transformAll(playerNames, s -> s.toUpperCase());
        upperNames.forEach(System.out::println);

        System.out.println();

        // TODO 2f
        System.out.println("Tagged names:");
        List<String> taggedNames = transformAll(playerNames, s -> "[LVL 1] " + s);
        taggedNames.forEach(System.out::println);

        System.out.println();


        // ════════════════════════════════════════════════════════════
        //  PART 3 TESTS
        // ════════════════════════════════════════════════════════════
        System.out.println("═══ PART 3: Configurable Behaviors ═══\n");

        // TODO 3b
        Consumer<Enemy> weaken = e -> e.health -= 10;
        applyToAll(enemies, weaken);

        // TODO 3c
        Consumer<Enemy> printStatus = e -> System.out.println("  " + e);
        System.out.println("After weakening all enemies:");
        applyToAll(enemies, printStatus);

        // TODO 3d
        Predicate<Enemy> isStrong = e -> e.health > 50;
        Predicate<Enemy> isHighDamage = e -> e.damage > 15;
        Predicate<Enemy> isBoss = isStrong.and(isHighDamage);

        System.out.println("\nBoss-tier enemies (HP > 50 AND DMG > 15):");
        List<Enemy> bosses = filterEnemies(enemies, isBoss);
        bosses.forEach(System.out::println);

        System.out.println();


        // ════════════════════════════════════════════════════════════
        //  PART 4 TESTS
        // ════════════════════════════════════════════════════════════
        System.out.println("═══ PART 4: Input Action Map ═══\n");

        // TODO 4a
        Map<String, Consumer<Player>> inputMap = new HashMap<>();
        inputMap.put("SPACE", p -> p.jump());
        inputMap.put("SHIFT", p -> p.dash());
        inputMap.put("E",     p -> p.interact());
        inputMap.put("F",     p -> p.attack());

        // TODO 4b
        List<String> pressedKeys = Arrays.asList("SPACE", "F", "E", "SPACE", "SHIFT");

        System.out.println("Simulating key presses:");
        for (String key : pressedKeys) {
            Consumer<Player> action = inputMap.get(key);
            if (action != null) {
                action.accept(player);
            }
        }

        System.out.println();

        // TODO 4c
        System.out.println("Spawned enemies:");
        Supplier<Enemy> enemySpawner = () -> new Enemy("Bat", 15, 3);
        List<Enemy> spawned = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            spawned.add(enemySpawner.get());
        }
        spawned.forEach(System.out::println);

        System.out.println();

        // ════════════════════════════════════════════════════════════
        //  FINAL STATUS
        // ════════════════════════════════════════════════════════════
        System.out.println("═══ FINAL STATUS ═══\n");
        System.out.println(player);
        System.out.println("\nAll enemies:");
        enemies.forEach(System.out::println);
    }
}
