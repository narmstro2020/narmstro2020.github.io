// ============================================
// Exception Handling Guided Notes
// Run each section one at a time by uncommenting
// ============================================

// Section01_WhatAreExceptions.Run();
// Section02_TryCatchBasics.Run();
// Section03_MultipleCatchBlocks.Run();
// Section04_TheFinallyBlock.Run();
// Section05_ExceptionProperties.Run();
// Section06_ThrowingExceptions.Run();
// Section07_CustomExceptions.Run();
