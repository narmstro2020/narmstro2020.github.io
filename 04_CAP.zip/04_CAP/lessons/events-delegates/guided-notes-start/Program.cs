// ============================================
// Events & Delegates Guided Notes
// Run each section one at a time by uncommenting
// ============================================

// Section01_WhatAreDelegates.Run();
// Section02_UsingDelegates.Run();
// Section03_MulticastDelegates.Run();
// Section04_AnonymousMethods.Run();
// Section05_LambdaExpressions.Run();
// Section06_IntroToEvents.Run();
// Section07_PuttingItTogether.Run();
